package com.stock.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.stock.persistence.StockAccountRepository;
import com.stock.service.StockAccountService;
import com.stock.service.StockAccountServiceImpl;

//TODO Declare as a configuration class
public class SpringServicesConfig {
	
	//TODO Inject the repository

	//TODO Declare the stock account service bean

}