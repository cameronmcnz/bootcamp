package com.stock.rest;

//TODO Declare the class is a REST Controller
//TODO Map the entire class to the /accounts URI
public class StockAccountResource {

	//TODO Inject the stock account service

	//TODO Create a method to retrieve all the stock accounts
	
	//TODO Create a method to retrieve a stock account by id
	
	//TODO Create a method to retrieve a stock account by name

}
