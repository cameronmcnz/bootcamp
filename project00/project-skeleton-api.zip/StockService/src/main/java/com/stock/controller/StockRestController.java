package com.stock.controller;

import com.stock.valueobjects.AccountInfo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/stocks")
public class StockRestController {

  static final String JSON = "application/json";

  // Create account
  @PostMapping(path = "/account", consumes = JSON, produces = JSON)
  @ResponseBody
  public AccountInfo createAccount(
      @RequestBody() AccountInfo accountInfo,
      HttpServletResponse response) {

    // we only allow creation of one account but we'll follow
    // follow RESTful convention and return the Location header
    response.setHeader("Location", "/stocks/account");
    response.setStatus(HttpServletResponse.SC_CREATED);

    return accountInfo;
  }

  // Get account
  @GetMapping(path = "/account", produces = JSON)
  @ResponseBody
  public String getAccount(HttpServletResponse response) {

    response.setStatus(HttpServletResponse.SC_OK);

    return "{\"data\":\"some data\"}";
  }

}
